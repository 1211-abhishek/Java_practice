package com.example.spring_crud.service;

import com.example.spring_crud.exceptions.EmployeeNotFoundException;
import com.example.spring_crud.model.Employee;
import com.example.spring_crud.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee getEmployee(int empId) {

        return employeeRepository.findById(empId).orElseThrow(()->new EmployeeNotFoundException("Employee with empId " + empId + " not found"));

    }

    public Employee postEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee putEmployee(Employee employee) {
        Employee existingEmp = employeeRepository.findById(employee.getEmpId())
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        if (employee.getEmpName() != null) {
            existingEmp.setEmpName(employee.getEmpName());
        }
        if (employee.getDepartment() != null) {
            existingEmp.setDepartment(employee.getDepartment());
        }

        return employeeRepository.save(existingEmp);
    }


    public boolean deleteEmployee(int empId) {

        Optional<Employee> employee = employeeRepository.findById(empId);
        if (employee.isPresent()) {

            employeeRepository.deleteById(empId);
            return true;
        }
        return false;
    }

    public List<Employee> getAllEmployees() {

        return employeeRepository.findAll();
    }
}
